module MypagesHelper

end
