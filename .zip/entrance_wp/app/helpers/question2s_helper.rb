module Question2sHelper
end
