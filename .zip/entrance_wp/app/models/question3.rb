class Question3 < ApplicationRecord


end
