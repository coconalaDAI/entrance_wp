# README

This README would normally document whatever steps are necessary to get the
application up and running.

Things you may want to cover:

* Ruby version
Ruby 2.4.2
Rails 5.1.6

* Configuration

* Database creation

$ bundle exec rails db:create
上記コマンドでDB作成

* Database initialization

$ bundle exec rails db:migrate
上記コマンドでDBのマイグレーション

* How to run the app

$ bundle exec rails s
でローカルサーバーを起動
localhost:3000へアクセス

* Deployment instructions
$ git push heroku master

* ...
